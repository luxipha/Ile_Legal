-- Migration to add user verification and admin management tables

-- Add verification fields to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS verification_status TEXT DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected', 'info_requested')),
ADD COLUMN IF NOT EXISTS verified_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS verified_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS rejected_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS rejection_reason TEXT,
ADD COLUMN IF NOT EXISTS verification_notes TEXT,
ADD COLUMN IF NOT EXISTS info_requested_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS requested_info TEXT;

-- Create user_documents table for storing verification documents
CREATE TABLE IF NOT EXISTS user_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL CHECK (document_type IN ('id_card', 'passport', 'drivers_license', 'professional_license', 'certificate', 'other')),
    document_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER,
    mime_type TEXT,
    verification_status TEXT DEFAULT 'pending' CHECK (verification_status IN ('pending', 'approved', 'rejected')),
    verified_at TIMESTAMPTZ,
    verified_by UUID REFERENCES auth.users(id),
    rejection_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create user_notifications table for admin-user communication
CREATE TABLE IF NOT EXISTS user_notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('info_request', 'verification_update', 'document_status', 'general')),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    requested_info TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    read_at TIMESTAMPTZ
);

-- Create admin_actions table for audit logging
CREATE TABLE IF NOT EXISTS admin_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_id UUID NOT NULL REFERENCES auth.users(id),
    action_type TEXT NOT NULL CHECK (action_type IN (
        'user_verified', 'user_rejected', 'info_requested', 'document_verified',
        'gig_flagged', 'gig_suspended', 'dispute_resolved', 'user_suspended'
    )),
    target_id UUID NOT NULL, -- Can reference users, gigs, disputes, etc.
    details JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS user_documents_user_id_idx ON user_documents(user_id);
CREATE INDEX IF NOT EXISTS user_documents_verification_status_idx ON user_documents(verification_status);
CREATE INDEX IF NOT EXISTS user_notifications_user_id_idx ON user_notifications(user_id);
CREATE INDEX IF NOT EXISTS user_notifications_is_read_idx ON user_notifications(is_read);
CREATE INDEX IF NOT EXISTS admin_actions_admin_id_idx ON admin_actions(admin_id);
CREATE INDEX IF NOT EXISTS admin_actions_action_type_idx ON admin_actions(action_type);
CREATE INDEX IF NOT EXISTS admin_actions_target_id_idx ON admin_actions(target_id);
CREATE INDEX IF NOT EXISTS profiles_verification_status_idx ON profiles(verification_status);

-- Create triggers to automatically update the updated_at column
CREATE TRIGGER update_user_documents_updated_at
BEFORE UPDATE ON user_documents
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Create RLS (Row Level Security) policies

-- Profiles table policies (users can only see their own profile, admins can see all)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" ON profiles
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() 
            AND role = 'admin'
        )
    );

-- User documents policies
ALTER TABLE user_documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own documents" ON user_documents
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own documents" ON user_documents
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own documents" ON user_documents
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all documents" ON user_documents
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() 
            AND role = 'admin'
        )
    );

-- User notifications policies
ALTER TABLE user_notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications" ON user_notifications
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON user_notifications
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all notifications" ON user_notifications
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() 
            AND role = 'admin'
        )
    );

-- Admin actions policies (only admins can access)
ALTER TABLE admin_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can access admin actions" ON admin_actions
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM profiles 
            WHERE id = auth.uid() 
            AND role = 'admin'
        )
    );

-- Create a function to automatically set user verification status
CREATE OR REPLACE FUNCTION handle_new_user_verification()
RETURNS TRIGGER AS $$
BEGIN
    -- Set default verification status for new users
    IF NEW.verification_status IS NULL THEN
        NEW.verification_status = 'pending';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new user verification
CREATE TRIGGER set_user_verification_status
    BEFORE INSERT ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION handle_new_user_verification();

-- Create a function to send notifications when verification status changes
CREATE OR REPLACE FUNCTION notify_verification_status_change()
RETURNS TRIGGER AS $$
BEGIN
    -- Only create notification if verification status actually changed
    IF OLD.verification_status IS DISTINCT FROM NEW.verification_status THEN
        INSERT INTO user_notifications (user_id, type, title, message, created_by)
        VALUES (
            NEW.id,
            'verification_update',
            CASE NEW.verification_status
                WHEN 'verified' THEN 'Account Verified'
                WHEN 'rejected' THEN 'Verification Rejected'
                WHEN 'info_requested' THEN 'Additional Information Required'
                ELSE 'Verification Status Updated'
            END,
            CASE NEW.verification_status
                WHEN 'verified' THEN 'Congratulations! Your account has been successfully verified.'
                WHEN 'rejected' THEN COALESCE('Your verification was rejected. Reason: ' || NEW.rejection_reason, 'Your verification was rejected.')
                WHEN 'info_requested' THEN COALESCE('Additional information is required: ' || NEW.requested_info, 'Additional information is required for verification.')
                ELSE 'Your verification status has been updated.'
            END,
            NEW.verified_by
        );
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for verification status change notifications
CREATE TRIGGER notify_on_verification_change
    AFTER UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION notify_verification_status_change();