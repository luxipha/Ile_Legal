-- Add Circle wallet fields to profiles table
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS circle_wallet_id UUID,
ADD COLUMN IF NOT EXISTS circle_wallet_address TEXT,
ADD COLUMN IF NOT EXISTS circle_wallet_created_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS circle_wallet_status TEXT DEFAULT 'pending';

-- Create a new table for wallet transactions
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    transaction_id TEXT NOT NULL,
    transaction_type TEXT NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'USD',
    status TEXT NOT NULL,
    source_id TEXT,
    destination_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    metadata JSONB
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS wallet_transactions_user_id_idx ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS wallet_transactions_transaction_id_idx ON wallet_transactions(transaction_id);

-- Create a function to update the updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to automatically update the updated_at column
CREATE TRIGGER update_wallet_transactions_updated_at
BEFORE UPDATE ON wallet_transactions
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Create a table for escrow transactions
CREATE TABLE IF NOT EXISTS escrow_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gig_id UUID NOT NULL,
    buyer_id UUID NOT NULL REFERENCES auth.users(id),
    seller_id UUID NOT NULL REFERENCES auth.users(id),
    transaction_id TEXT NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    release_condition TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    released_at TIMESTAMPTZ,
    metadata JSONB
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS escrow_transactions_gig_id_idx ON escrow_transactions(gig_id);
CREATE INDEX IF NOT EXISTS escrow_transactions_buyer_id_idx ON escrow_transactions(buyer_id);
CREATE INDEX IF NOT EXISTS escrow_transactions_seller_id_idx ON escrow_transactions(seller_id);

-- Create a trigger to automatically update the updated_at column
CREATE TRIGGER update_escrow_transactions_updated_at
BEFORE UPDATE ON escrow_transactions
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();
